<?php
/**
 * Interfaz general de las fachadas.
 * @author Miguel Callon
 */
interface IFachada {
	
}
?>