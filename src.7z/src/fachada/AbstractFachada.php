<?php
/**
 * Clase que implementa los metodos comunes de las fachadas.
 * @author Miguel Callon
 */
abstract class AbstractFachada implements IFachada {
	
}
?>