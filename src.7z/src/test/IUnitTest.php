<?php
/**
 * Interface que implementan los test unitarios
 * @author Miguel Callon
 */
interface IUnitTest {
}
?>