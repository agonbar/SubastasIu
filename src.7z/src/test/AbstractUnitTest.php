<?php
/**
 * Clase abstracta que que implementa los metodos abstractos de los
 * test unitarios
 * @author Miguel Callon
 */
class AbstractUnitTest implements IUnitTest {
}
?>