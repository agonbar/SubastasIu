<?php
/**
 * Clase generica de error para manejar excepciones en el controlador.
 * @author Miguel Callon
 */
class ControladorException extends GeneralException {
	
}
?>