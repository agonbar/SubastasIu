<?php
 /**
 * Excepcion cuando hay un error en los campos de la nueva clave
 * @author Miguel Callon
 */
class DatPassDAOEx extends DAOException {
	
}

?>