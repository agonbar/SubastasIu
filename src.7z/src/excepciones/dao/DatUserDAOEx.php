<?php
/**
 * Excepcion cuando se produce un error al modificar algun dato de usuario
 * @author Santiago Iglesias
 */
class DatUserDAOEx extends DAOException {
	
}
?>