<?php
 /**
 * Excepcion cuando no se puede insertar una linea de pedido
 * @author Miguel Callon
 */
class InsertarLineaPedidoDAOEx extends DAOException {
	
}

?>