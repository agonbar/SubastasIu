<?php
/**
 * Excepcion cuando los datos de login introducidos son incorrectos
 * @author Miguel Callon
 */
class ClaveIncorrectaDAOEx extends DAOException {
	
}
?>