<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * un usuario son incorrectos.
 * @author Santiago Iglesias
 */
class ConsultarEstadoUsuDAOEx extends DAOException {
	
}

?>