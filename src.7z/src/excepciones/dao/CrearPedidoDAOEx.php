<?php
 /**
 * Excepcion cuando no se puede crear un pedido
 * @author Miguel Callon
 */
class CrearPedidoDAOEx extends DAOException {
	
}

?>