<?php
 /**
 * Excepcion cuando no se puede modificar el informe
 * @author Nuria Canle
 */
class ModificarInformeDAOEx extends DAOException {
	
}

?>