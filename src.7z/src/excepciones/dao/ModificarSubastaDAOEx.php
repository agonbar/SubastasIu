<?php
/**
 * Excepcion cuando los datos introducidos al modificar
 * una subasta son incorrectos.
 * @author Miguel Callon
 */
class ModificarSubastaDAOEx extends DAOException {
	
}
?>