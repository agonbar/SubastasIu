<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * las pujas de una subasta son incorrectos
 * @author Miguel Callon
 */
class ConsultarLineaPujaDAOEx extends DAOException {
	
}

?>