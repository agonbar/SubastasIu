<?php
 /**
 * Excepcion cuando existe un error al recuperar la puja
 * ganadora
 * @author Miguel Callon
 */
class ConsultarPujaGanadoraSubDAOEx extends DAOException {
	
}

?>