<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * un usuario son incorrectos.
 * @author Miguel Callon
 */
class ConsultarEstadoPedDAOEx extends DAOException {
	
}

?>