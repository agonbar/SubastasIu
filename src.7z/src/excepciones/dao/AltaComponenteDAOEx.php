<?php
/**
 * Excepcion 
 * @author Almudena Novoa
 */
class AltaComponenteDAOEx extends DAOException {
	
}
?>