<?php
 /**
 * Excepcion cuando no se puede pasar la puja al nuevo estado
 * de puja perdedora
 * @author Miguel Callon
 */
class MarcarPujaPerdedoraDAOEx extends DAOException {
	
}

?>