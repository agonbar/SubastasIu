<?php
 /**
 * Excepcion cuando no se puede consultar una subasta
 * @author Miguel Callon
 */
class ConsultarSubastaDAOEx extends DAOException {
	
}

?>