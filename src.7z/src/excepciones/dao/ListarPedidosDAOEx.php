<?php
/**
 * Excepcion cuando se produce un error a la hora de 
 * listar los pedidos.
 * @author Miguel Callon
 */
class ListarPedidosDAOEx extends DAOException {
	
}
?>