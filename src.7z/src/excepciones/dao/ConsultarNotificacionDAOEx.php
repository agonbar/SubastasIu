<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * una notificacion son incorrectos.
 * @author Almudena Novoa
 */
class ConsultarNotificacionDAOEx extends DAOException {
	
}

?>