<?php
 /**
 * Excepcion cuando no se puede realiza una puja en una subasta
 * @author Miguel Callon
 */
class PujarDAOEx extends DAOException {
	
}

?>