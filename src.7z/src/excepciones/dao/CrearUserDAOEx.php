<?php
 /**
 * Excepcion cuando no se puede guardar el nuevo usuario
 * @author Miguel Callon
 */
class CrearUserDAOEx extends DAOException {
	
}

?>