<?php
 /**
 * Excepcion cuando no existen pujas en una subasta
 * @author Miguel Callon
 */
class NoExistenPujasDAOEx extends DAOException {
	
}

?>