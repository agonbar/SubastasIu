<?php
 /**
 * Excepcion cuando no se puede insertar en historico de subastas
 * @author Miguel Callon
 */
class InsertarHistSubastaDAOEx extends DAOException {
	
}

?>