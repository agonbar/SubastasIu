<?php
 /**
 * Excepcion cuando no se puede pasar el pedido al nuevo estado
 * @author Santiago Iglesias
 */
class ModificarFinDeSubastaDAOEx extends DAOException {
	
}

?>