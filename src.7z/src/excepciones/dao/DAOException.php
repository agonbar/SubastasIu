<?php
/**
 * Clase generica de excepcion para manejar errores en el DAO.
 * @author Miguel Callon
 */
class DAOException extends GeneralException {
	
}
?>