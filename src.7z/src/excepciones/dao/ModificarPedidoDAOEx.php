<?php
 /**
 * Excepcion cuando los datos introducidos al modificar
 * un pedido son incorrectos.
 * @author Nuria Canle
 */
class ModificarPedidoDAOEx extends DAOException {
	
}
?>