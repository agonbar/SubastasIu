<?php
 /**
 * Excepcion cuando no se puede devolver el numero de notificaciones
 * @author Santiago Iglesias
 */
class ConsultarNumNotificacionesDAOEx extends DAOException {
	
}

?>