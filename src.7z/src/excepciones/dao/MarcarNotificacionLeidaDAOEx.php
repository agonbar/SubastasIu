<?php
 /**
 * Excepcion cuando no se puede marcar una notificacion como leida
 * @author Miguel Callon
 */
class MarcarNotificacionLeidaDAOEx extends DAOException {
	
}

?>