<?php
 /**
 * Excepcion cuando no se puede insertar una notificacion
 * en base de datos
 * @author Miguel Callon
 */
class InsertarNotificacionDAOEx extends DAOException {
	
}

?>