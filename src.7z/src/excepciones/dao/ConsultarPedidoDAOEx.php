<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * un pedido son incorrectos.
 * @author Santiago Iglesias
 */
class ConsultarPedidoDAOEx extends DAOException {
	
}

?>