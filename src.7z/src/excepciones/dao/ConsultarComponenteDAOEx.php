<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * un componete son incorrectos.
 * @author Miguel Callon
 */
class ConsultarComponenteDAOEx extends DAOException {
	
}

?>