<?php
    /**
 * Excepcion cuando se produce un error a la hora de 
 * listar los informes.
 * @author Nuria Canle
 */
class ListarInformesDAOEx extends DAOException {
	
}
?>