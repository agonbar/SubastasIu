<?php
 /**
 * Excepcion cuando no se puede pasar el pedido al nuevo estado
 * @author Adrián González
 */
class AnularPedidoDelSistemaDAOEx extends DAOException {
	
}

?>