<?php
/**
 * Excepcion cuando se produce un error a la hora de 
 * listar los usuarios.
 * @author Santiago Iglesias
 */
class ListarUsuariosDAOEx extends DAOException {
	
}
?>