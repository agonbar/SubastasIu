<?php
 /**
 * Excepcion cuando los datos introducidos al consultar
 * una linea de pedido son incorrectos.
 * @author Santiago Iglesias
 */
class ConsultarLineaPedidoDAOEx extends DAOException {
	
}

?>