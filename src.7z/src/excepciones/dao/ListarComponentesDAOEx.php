<?php
/**
 * Excepcion cuando se produce un error a la hora de 
 * listar los componentes.
 * @author Nuria Canle
 */
class ListarComponentesDAOEx extends DAOException {
	
}
?>