<?php
/**
 * Excepcion cuando se intenta insertar la foto de un componente 
 * @author Miguel Callon
 */
class AltaFotoComponenteDAOEx extends DAOException {
	
}
?>