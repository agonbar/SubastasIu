<?php
 /**
 * Excepcion cuando los datos de la puja son incorrectos
 * @author Miguel Callon
 */
class PujaDatosIncFacEx extends FachadaException {
	
}

?>