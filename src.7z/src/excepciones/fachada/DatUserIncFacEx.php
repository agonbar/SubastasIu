<?php
 /**
 * Excepcion cuando los datos del usuario que se registra
 * son incorrectos 
 * @author Miguel Callon
 */
class DatUserIncFacEx extends FachadaException {
	
}

?>