<?php
/**
 * Excepcion cuando se produce un error listando notificaciones
 * @author Almudena Novoa
 */
class NotDatosIncFacEx extends FachadaException {
	
}
?>