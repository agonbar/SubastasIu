<?php
 /**
 * Excepcion cuando no se puede marcar el pedido como recibido.
 * @author Santiago Iglesias
 */
class MarcarPedidoRecibidoFacEx extends FachadaException {
	
}

?>