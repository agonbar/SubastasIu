<?php
 /**
 * Excepcion cuando no se puede marcar el pedido como aceptado.
 * @author Santiago Iglesias
 */
class AceptarPedidoFacEx extends FachadaException {
	
}

?>