<?php
/**
 * Excepcion cuando hay algun error al listar subastas.
 * @author Miguel Callon
 */
class ListarPedidosFacEx extends FachadaException {
	
}
?>