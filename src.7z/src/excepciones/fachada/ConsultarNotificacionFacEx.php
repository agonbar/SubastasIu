<?php
   
/**
 * Excepcion cuando no se puede consultar un componente
 * @author Almudena Novoa
 */
class ConsultarNotificacionFacEx extends FachadaException {
	
}
?>