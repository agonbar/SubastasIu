<?php
 /**
 * Excepcion cuando no se puede marcar el pedido como  no recibido.
 * @author Santiago Iglesias
 */
class MarcarPedidoNoRecibidoFacEx extends FachadaException {
	
}

?>