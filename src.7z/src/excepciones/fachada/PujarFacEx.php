<?php
 /**
 * Excepcion cuando no se puede pujar en la subasta
 * @author Miguel Callon
 */
class PujarFacEx extends FachadaException {
	
}

?>