<?php
    /**
 * Excepcion cuando al introducir los datos para intentar
 * crear los informes aparece un error desconocido.
 * @author Nuria Canle
 */
class CrearInformeFacEx extends FachadaException {
	
}
?>