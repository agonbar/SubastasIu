<?php
     /**
 * Excepcion cuando no se pueden cambiar los datos de un pedido
 * @author Nuria Canle
 */
class ModificarPedidoFacEx extends FachadaException {
	
}
?>