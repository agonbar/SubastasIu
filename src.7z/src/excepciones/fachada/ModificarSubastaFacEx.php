<?php
/**
 * Excepcion cuando los datos introducidos al intentar
 * modificar los datos pero aparece un error desconocido.
 * @author Miguel Callon
 */
class ModificarSubastaFacEx extends FachadaException {
	
}
?>