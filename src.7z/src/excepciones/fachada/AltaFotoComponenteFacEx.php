<?php
/**
 * Excepcion para cuando se intenta insertar la foto de un componente
 * @author Miguel Callon
 */
class AltaFotoComponenteFacEx extends FachadaException {
	
}
?>