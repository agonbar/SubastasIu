<?php
 /**
 * Excepcion cuando no se puede marcar el pedido como anulado.
 * @author Adrián González
 */
class AnularPedidoDelSistemaFacEx extends FachadaException {
	
}

?>