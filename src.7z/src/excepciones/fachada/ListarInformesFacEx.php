<?php
    /**
 * Excepcion cuando al introducir los datos para
 * listar los informes se produce un error desconocido.
 * @author Nuria Canle
 */
class ListarInformesFacEx extends FachadaException {
	
}
?>