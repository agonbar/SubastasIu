<?php
    /**
 * Excepcion cuando los datos introducidos al crear
 * un informe son incorrectos.
 * @author Nuria Canle
 */
class InfDatosIncFacEx extends FachadaException {
	
}
?>