<?php
   

/**
 * Excepcion cuando los datos del pago son incorrectos
 * @author Miguel Callon
 */
class RealizarPagoDatosIncFacEx extends FachadaException {
	
}
   
   
   
   
?>