<?php
 /**
 * Excepcion cuando no se puede enviar una notificacion
 * @author Miguel Callon
 */
class EnviarNotificacionFacEx extends FachadaException {
	
}

?>