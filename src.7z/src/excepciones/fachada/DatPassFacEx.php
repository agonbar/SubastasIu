<?php
/**
 * Clase de excepcion para manejar errores de los datos del validacion.
 * @author Adrian Gonzalez
 */
class DatPassFacEx extends FachadaException {
	
}
?>