<?php
   

/**
 * Excepcion cuando no se puede realizar la consulta
 * de un pedido
 * @author Santiago Iglesias
 */
class ConsultarPedidoFacEx extends FachadaException {
	
}
   
   
   
   
?>