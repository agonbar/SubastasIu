<?php
/**
 * Clase generica de excepcion para manejar errores de la fachada.
 * @author Miguel Callon
 */
class LoginFacEx extends GeneralException {
	
}
?>