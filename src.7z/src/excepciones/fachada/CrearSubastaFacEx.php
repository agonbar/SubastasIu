<?php
/**
 * Excepcion cuando los datos introducidos al intentar
 * crear los datos pero aparece un error desconocido.
 * @author Miguel Callon
 */
class CrearSubastaFacEx extends FachadaException {
	
}
?>