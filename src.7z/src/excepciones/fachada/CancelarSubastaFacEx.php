<?php
   

/**
 * Excepcion cuando no se puede cancelar una subasta
 * @author Miguel Callon
 */
class CancelarSubastaFacEx extends FachadaException {
	
}
?>