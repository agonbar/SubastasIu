<?php

/**
 * Excepcion cuando no se puede eliminar componentes del carrito
 * @author Hector Riopedre
 */
class EliminarDeCarritoFacEx extends FachadaException {

}
?>