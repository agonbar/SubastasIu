<?php
   

/**
 * Excepcion cuando no se puede anhadir al carrito
 * @author Hector Riopedre
 */
class AnhadirACarritoFacEx extends FachadaException {
	
}
?>