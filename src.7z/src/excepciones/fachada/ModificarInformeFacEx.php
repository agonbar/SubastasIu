<?php
 /**
 * Excepcion cuando no se puede modificar un informe
 * @author Nuria Canle
 */
class ModificarInformeFacEx extends FachadaException {
	
}

?>