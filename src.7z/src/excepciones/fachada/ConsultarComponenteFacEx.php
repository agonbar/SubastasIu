<?php
   

/**
 * Excepcion cuando no se puede consultar un componente
 * @author Miguel Callon
 */
class ConsultarComponenteFacEx extends FachadaException {
	
}
?>