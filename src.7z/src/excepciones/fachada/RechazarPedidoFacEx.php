<?php
 /**
 * Excepcion cuando no se puede marcar el pedido como rechazado.
 * @author Santiago Iglesias
 */
class RechazarPedidoFacEx extends FachadaException {
	
}

?>