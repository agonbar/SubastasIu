<?php
   

/**
 * Excepcion cuando no se puede realizar el pago de un
 * pedido
 * @author Miguel Callon
 */
class RealizarPagoFacEx extends FachadaException {
	
}
   
   
   
   
?>