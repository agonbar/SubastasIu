<?php
/**
 * Excepcion cuando los datos introducidos al intentar
 * crear los datos pero aparece un error desconocido.
 * @author Santiago Iglesias
 */
class ListarSubastasFacEx extends FachadaException {
	
}
?>