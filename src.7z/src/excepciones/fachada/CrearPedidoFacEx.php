<?php
 /**
 * Excepcion cuando no se puede crear un pedido
 * @author Miguel Callon
 */
class CrearPedidoFacEx extends FachadaException {
	
}

?>