<?php
/**
 * Excepcion cuando los datos introducidos al crear
 * una subasta son incorrectos.
 * @author Miguel Callon
 */
class SubDatosIncFacEx extends FachadaException {
	
}
?>