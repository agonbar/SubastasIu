<?php
/**
 * Excepcion para cuando se intenta modificar un componente.
 * @author Almudena Novoa
 */
class ModificarComponenteFacEx extends FachadaException {
	
}
?>