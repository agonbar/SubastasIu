<?php
/**
 * Excepcion para cuando se intenta dar de alta un componente.
 * @author Almudena Novoa
 */
class AltaComponenteFacEx extends FachadaException {
	
}
?>