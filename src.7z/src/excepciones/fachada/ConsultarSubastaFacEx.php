<?php
   

/**
 * Excepcion cuando no se puede consultar una subasta
 * @author Miguel Callon
 */
class ConsultarSubastaFacEx extends FachadaException {
	
}
?>