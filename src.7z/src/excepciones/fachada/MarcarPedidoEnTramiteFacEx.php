<?php
 /**
 * Excepcion cuando no se puede pasar el pedido al nuevo estado
 * @author Miguel Callon
 */
class MarcarPedidoEnTramiteFacEx extends FachadaException {
	
}

?>