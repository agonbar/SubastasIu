<?php
/**
 * Excepcion para cuando se intenta dar de alta un componente.
 * @author Santiago Iglesias
 */
class BajaComponenteFacEx extends FachadaException {
	
}
?>