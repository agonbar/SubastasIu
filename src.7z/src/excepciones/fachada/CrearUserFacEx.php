<?php
 /**
 * Excepcion cuando no se puede guardar el nuevo usuario
 * @author Miguel Callon
 */
class CrearUserFacEx extends DAOException {
	
}

?>