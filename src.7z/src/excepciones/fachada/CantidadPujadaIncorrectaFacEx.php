<?php
 /**
 * Excepcion cuando la cuantia de la nueva puja es menor o igual
 * que la puja ganadora de la subasta.
 * @author Miguel Callon
 */
class CantidadPujadaIncorrectaFacEx extends FachadaException {
	
}

?>