<?php
/**
 * Excepcion cuando los datos introducidos al dar de alta un componente son incorrectos.
 * @author Nuria Canle
 */
class CompDatosFacEx extends FachadaException {
	
}
?>