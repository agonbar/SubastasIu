<?php
/**
 * Clase de excepcion para manejar errores de los datos del usuario.
 * @author Adrián González
 */
class datUserEx extends FachadaException {
	
}
?>