<?php
/**
 * Excepcion cuando al introducir los datos para
 * listar los componentes se produce un error desconocido.
 * @author Nuria Canle
 */
class ListarComponentesFacEx extends FachadaException {
	
}
?>