<?php
   

/**
 * Excepcion cuando no se puede consultar el carrito
 * @author Hector Riopedre
 */
class ConsultarCarritoFacEx extends FachadaException {
	
}
?>