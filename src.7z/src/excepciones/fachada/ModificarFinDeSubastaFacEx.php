<?php
 /**
 * Excepcion cuando no se puede cambiar la fecha de cierre
 * de una subasta.
 * @author Miguel Callon
 */
class ModificarFinDeSubastaFacEx extends FachadaException {
	
}

?>