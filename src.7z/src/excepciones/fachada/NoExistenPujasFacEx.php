<?php
/**
 * Excepcion para cuando no existen pujas en la subasta
 * y se intenta obtener la puja ganadora
 * @author Miguel Callon
 */
class NoExistenPujasFacEx extends FachadaException {
	
}
?>