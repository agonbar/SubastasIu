<?php
/**
 * Clase que implementa los metodos de base de datos contra MySQL
 * de la entidad HistoricoPedido
 * @author Miguel Callon
 */
class HistoricoPedidoDAO extends MysqlDAO implements IHistoricoPedidoDAO {

}
?>