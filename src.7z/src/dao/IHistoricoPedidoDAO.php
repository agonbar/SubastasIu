<?php
/**
 * Clase que almacena los datos del historico de pedido.
 * @author Miguel Callon
 */
 
interface IHistoricoPedidoDAO extends IDAO {
}
?>