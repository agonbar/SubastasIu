<?php
/**
 * Clase que contiene los metodos independientes de la 
 * base de datos.
 * @author Miguel Callon
 */
abstract class AbstractDAO implements IDAO {

}
?>