<?php
	include HTML_ADMIN_PATH."/cabecera.php";
?>

<div class="box_content">
	<div class="box_title">
    	<div class="title_icon"><img src="./recursos/img/mini_icon3.gif" alt="" title=""></div>
        <h2><?php MultiIdioma::gettexto("inicio.admin.titulo") ?></h2>
    </div>
    <div class="box_text_content">
        <div class="box_text_registro">
		</div>
	</div>
</div>

<?php
	include HTML_ADMIN_PATH."/pie.php";
?>