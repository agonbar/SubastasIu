<?php
	/**
	 * Pagina de error cuando existe algun problema consultando
	 * el detalle de un componente
	 * @author Santiago
	 */
	include HTML_ADMIN_PATH."/cabecera.php";
?>
<p>El componente seleccionado no esta disponible.</p>
<?php
	include HTML_ADMIN_PATH."/pie.php";
?>