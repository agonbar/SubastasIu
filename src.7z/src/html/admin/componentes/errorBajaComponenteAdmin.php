<?php
	/**
	 * Pagina de error cuando existe algun problema eliminando
	 * un componente
	 * @author Santiago Iglesias
	 */
	include HTML_ADMIN_PATH."/cabecera.php";
?>
<p>El componente seleccionado no se pudo eliminar.</p>
<?php
	include HTML_ADMIN_PATH."/pie.php";
?>