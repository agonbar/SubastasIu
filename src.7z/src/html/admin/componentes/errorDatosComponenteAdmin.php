<?php
	/**
	 * Pagina de error cuando existe algun problema en los datos
	 * para eliminar un componente
	 * @author Santiago Iglesias
	 */
	include HTML_ADMIN_PATH."/cabecera.php";
?>
<p>Los datos componente a eliminar son incorrectos.</p>
<?php
	include HTML_ADMIN_PATH."/pie.php";
?>