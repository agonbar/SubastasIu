<?php
	/**
	 * Pagina de aviso cuando se ha eliminando
	 * un componente
	 * @author Adrian Gonzalez
	 */
	include HTML_ADMIN_PATH."/cabecera.php";
?>
<p>El componente seleccionado se elimino satisfactoriamente.</p>
<?php
	include HTML_ADMIN_PATH."/pie.php";
?>