<?php
	/**
	 * Pagina de error cuando existe algun problema consultando
	 * una notificacion
	 * @author Almudena Novoa
	 */
	include HTML_PRIVADA_PATH."/cabecera.php";
?>
<p>El mensaje seleccionado no esta disponible.</p>
<?php
	include HTML_PRIVADA_PATH."/pie.php";
?>