	    <div class="clear"></div>
	</div>
	<div id="footer">
		<div class="copyright">
        	<!--<img src="images/footer_logo.gif" alt="" title="">-->
        </div>
		<div class="center_footer">Copyright by Grupo3 IU 2013/2014</div>
	</div>
</div>


</body>
</html>