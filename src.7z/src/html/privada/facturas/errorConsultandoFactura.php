<?php
	/**
	 * Pagina de error cuando existe algun problema consultando
	 * el detalle de una factura
	 * @author Adrian Gonzalez
	 */
	include HTML_PRIVADA_PATH."/cabecera.php";
?>
<p>La factura seleccionada no esta disponible.</p>
<?php
	include HTML_PRIVADA_PATH."/pie.php";
?>