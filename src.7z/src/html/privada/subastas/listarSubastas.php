<?php
  
foreach ($listaSubastas as $subasta) {
	echo "<br/>";
	echo $subasta;
}
  
?>